function bm_addMarkers(csv){
  var seq=app.project.activeSequence;
  if(!seq)return JSON.stringify({ok:false,error:'No active sequence.'});
  var markers=seq.markers;
  if(!markers)return JSON.stringify({ok:false,error:'Sequence markers unavailable.'});
  var values=csv.split(','),made=0;
  for(var i=0;i<values.length;i++){
    var t=parseFloat(values[i]);
    if(isNaN(t)||t<0)continue;
    var m=markers.createMarker(t);
    if(m){m.name='Beat '+(made+1);m.comments='Beat Marker';made++;}
  }
  return JSON.stringify({ok:true,count:made});
}
function bm_clearMarkers(){
  var seq=app.project.activeSequence;
  if(!seq)return JSON.stringify({ok:false,error:'No active sequence.'});
  var markers=seq.markers;
  if(!markers)return JSON.stringify({ok:false,error:'Sequence markers unavailable.'});
  var count=0,m=markers.getFirstMarker();
  while(m){
    var next=markers.getNextMarker(m);
    try{markers.deleteMarker(m);count++;}catch(e){}
    m=next;
  }
  return JSON.stringify({ok:true,count:count});
}
