(function(){
var beats=[];
function $id(id){return document.getElementById(id)}
$id('sens').oninput=function(){$id('sensVal').textContent=this.value};
function status(s){$id('status').textContent=s}
function cep(code){
  if(window.__adobe_cep__) window.__adobe_cep__.evalScript(code);
}
function detect(buf){
  var sr=buf.sampleRate,n=buf.length;
  var mono=new Float32Array(n),ch=buf.numberOfChannels;
  for(var c=0;c<ch;c++){
    var d=buf.getChannelData(c);
    for(var i=0;i<n;i++) mono[i]+=d[i]/ch;
  }
  var hop=Math.max(128,Math.floor(sr*.01)),win=Math.floor(sr*.02);
  var env=[],flux=[];
  for(var p=0;p+win<n;p+=hop){
    var sum=0;
    for(var j=0;j<win;j++){var x=mono[p+j];sum+=x*x}
    env.push(Math.sqrt(sum/win));
  }
  var smooth=5;
  for(var k=0;k<env.length;k++){
    var a=0,cnt=0;
    for(var q=Math.max(0,k-smooth);q<=k;q++){a+=env[q];cnt++}
    flux[k]=Math.max(0,env[k]-a/cnt);
  }
  var mean=flux.reduce(function(a,b){return a+b},0)/(flux.length||1);
  var sens=parseFloat($id('sens').value);
  var max=flux.reduce(function(a,b){return Math.max(a,b)},0);
  var thr=mean+(max-mean)*(1-sens)*.35;
  var minFrames=Math.max(1,Math.round(parseInt($id('spacing').value)/(hop/sr*1000)));
  var raw=[];
  for(var z=1;z<flux.length-1;z++){
    if(flux[z]>thr&&flux[z]>=flux[z-1]&&flux[z]>=flux[z+1]){
      if(!raw.length||z-raw[raw.length-1]>=minFrames) raw.push(z);
      else if(flux[z]>flux[raw[raw.length-1]]) raw[raw.length-1]=z;
    }
  }
  var times=raw.map(function(x){return x*hop/sr});
  var mode=$id('mode').value;
  if(mode==='strong') times=times.filter(function(t,i){return i===0||flux[raw[i]]>=thr*1.5});
  if(mode==='half') times=times.filter(function(t,i){return i%2===0});
  var intervals=[];
  for(var u=1;u<times.length;u++){
    var d=times[u]-times[u-1];
    if(d>.25&&d<2) intervals.push(d);
  }
  intervals.sort(function(a,b){return a-b});
  var med=intervals.length?intervals[Math.floor(intervals.length/2)]:0;
  return {times:times,bpm:med?60/med:0,duration:n/sr};
}
$id('analyze').onclick=async function(){
  var f=$id('audio').files[0];
  if(!f){status('Choose an audio file first.');return}
  status('Analyzing audio…');
  try{
    var AC=window.AudioContext||window.webkitAudioContext;
    var ac=new AC(),data=await f.arrayBuffer(),buf=await ac.decodeAudioData(data),r=detect(buf);
    beats=r.times;
    $id('bpm').textContent=r.bpm?r.bpm.toFixed(1):'—';
    $id('count').textContent=beats.length;
    $id('duration').textContent=r.duration.toFixed(2)+' s';
    $id('preview').textContent=beats.slice(0,100).map(function(t,i){return (i+1)+': '+t.toFixed(3)+'s'}).join('\n');
    status('Analysis complete.');
    if(ac.close) ac.close();
  }catch(e){status('Audio analysis failed: '+e.message)}
};
$id('create').onclick=function(){
  if(!beats.length){status('Analyze audio first.');return}
  var off=parseFloat($id('offset').value)||0;
  var vals=beats.map(function(t){return Math.max(0,t+off).toFixed(3)});
  cep('bm_addMarkers("'+vals.join(',')+'")');
  status('Creating '+vals.length+' sequence markers…');
};
$id('clear').onclick=function(){
  cep('bm_clearMarkers()');
  status('Clearing sequence markers…');
};
})();
